import random

# Cartas com atributos
cartas = [
    {"nome": "Ninja", "forca": 6, "velocidade": 9, "inteligencia": 7},
    {"nome": "Samurai", "forca": 8, "velocidade": 6, "inteligencia": 5},
    {"nome": "Guerreiro", "forca": 7, "velocidade": 5, "inteligencia": 6}
]

# Sorteio das cartas
carta_jogador = random.choice(cartas)
carta_computador = random.choice([c for c in cartas if c != carta_jogador])

print("Sua carta é:")
for atributo, valor in carta_jogador.items():
    if atributo != "nome":
        print(f"{atributo.capitalize()}: {valor}")
print(f"Nome: {carta_jogador['nome']}")

# Jogador escolhe atributo
atributo = input("Escolha um atributo (forca, velocidade, inteligencia): ").lower()

# Mostrar e comparar
print(f"\nCarta do computador: {carta_computador['nome']}")
print(f"Sua {atributo}: {carta_jogador[atributo]}")
print(f"Computador {atributo}: {carta_computador[atributo]}")

# Decisão lógica
if carta_jogador[atributo] > carta_computador[atributo]:
    print("\nVocê venceu!")
elif carta_jogador[atributo] < carta_computador[atributo]:
    print("\nVocê perdeu.")
else:
    print("\nEmpate!")